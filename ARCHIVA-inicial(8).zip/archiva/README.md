# ARCHIVA

Aplicación privada de biblioteca visual. Stack: React 19, TypeScript, Vite y Supabase.

## Incluye
- Autenticación por correo y contraseña, más inicio con Google (requiere habilitar Google en Supabase Auth y cargar credenciales OAuth).
- Biblioteca privada con Supabase Storage.
- Subida múltiple de imágenes (JPEG, PNG, WebP, GIF, AVIF y HEIC; máximo 50 MB por archivo).
- Carpetas: crear, renombrar y eliminar cuando estén vacías.
- Etiquetas: crear etiquetas y asignarlas a imágenes desde el editor.
- Búsqueda por nombre, título y descripción.
- Cuadrícula y recorrido vertical con scroll.
- Edición de título, descripción, carpeta y personaje; eliminación de imágenes.
- Diseño responsive con estética oscura ciruela, rosa empolvado y lavanda.

## Requisitos
Node.js 20.19+ o 22.12+.

## Configuración
1. Copiá `.env.example` como `.env`.
2. En Supabase, copiá la Project URL y la publishable key.
3. Completá `VITE_SUPABASE_URL` y `VITE_SUPABASE_PUBLISHABLE_KEY`.
4. Ejecutá `npm install`.
5. Ejecutá `npm run dev`.

No coloques `service_role` ni secretos en variables `VITE_*`: se exponen al navegador.

## Supabase esperado
El proyecto usa las tablas `profiles`, `folders`, `images`, `tags`, `image_tags` y el bucket privado `archiva-images`, con RLS y políticas de Storage que limitan cada ruta al UUID del usuario. Las rutas de archivos se guardan como `{user_id}/{filename}`.

La relación de etiquetas requiere las tablas ya creadas:
- `tags(id, user_id, name, created_at, updated_at)`
- `image_tags(user_id, image_id, tag_id, created_at)`

Si tu índice único de tags usa `lower(name)` en vez de `(user_id,name)`, cambia el `upsert` de `src/App.tsx` por una búsqueda previa y un `insert` condicionado.

## Estado
Este es un scaffold de desarrollo, no un servicio desplegado. Antes de publicar: ejecutar build y pruebas, configurar Google OAuth si se desea, revisar límites y formatos HEIC en navegadores objetivo, añadir paginación y pruebas de recuperación ante fallos de Storage/DB.
\n## Migraciones\nLas migraciones de `supabase/migrations/` documentan el esquema de personajes y los índices aplicados en Supabase.\n\n## Google OAuth\nEn Supabase Dashboard → Authentication → Providers → Google, habilitá el proveedor y cargá Client ID/Secret de Google Cloud. En Authentication → URL Configuration, agregá los dominios locales y de producción permitidos. El botón de Google ya está integrado en la interfaz, pero no funcionará hasta completar esas credenciales.\n