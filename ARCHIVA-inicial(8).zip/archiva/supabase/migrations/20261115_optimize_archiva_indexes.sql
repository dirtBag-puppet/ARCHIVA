create index if not exists folders_parent_owner_idx on public.folders(parent_id, user_id);
create index if not exists image_tags_image_owner_idx on public.image_tags(image_id, user_id);
create index if not exists image_tags_tag_owner_idx on public.image_tags(tag_id, user_id);
create index if not exists image_tags_user_owner_idx on public.image_tags(user_id);
create index if not exists images_character_owner_idx on public.images(character_id, user_id);
create index if not exists images_folder_owner_idx on public.images(folder_id, user_id);
drop policy if exists "Users manage their own characters" on public.characters;
create policy "Users manage their own characters" on public.characters
for all to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);
