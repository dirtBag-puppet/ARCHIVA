create table if not exists public.characters (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(trim(name)) between 1 and 120),
  slug text not null check (char_length(trim(slug)) between 1 and 140),
  description text,
  cover_path text,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (id, user_id)
);
create unique index if not exists characters_user_slug_idx on public.characters(user_id, lower(slug));
alter table public.characters enable row level security;
drop policy if exists "Users manage their own characters" on public.characters;
create policy "Users manage their own characters" on public.characters
for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
alter table public.images add column if not exists character_id uuid;
alter table public.images drop constraint if exists images_character_owner_fkey;
alter table public.images add constraint images_character_owner_fkey
foreign key (character_id, user_id) references public.characters(id, user_id)
on delete set null (character_id);
create index if not exists images_character_id_idx on public.images(character_id);
