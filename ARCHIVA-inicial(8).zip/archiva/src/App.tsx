import { useEffect, useMemo, useState } from "react";
import type { FormEvent } from "react";
import { supabase, isSupabaseConfigured } from "./lib/supabase";
import {
  Archive, Search, Plus, Upload, Folder, FolderPlus, Image as ImageIcon,
  LayoutGrid, Rows3, LogOut, X, Trash2, Pencil, Check, Tag, ChevronLeft,
  ChevronRight, Menu, Sparkles
} from "lucide-react";

type FolderRow = { id: string; name: string; description: string | null; parent_id: string | null; sort_order: number };
type ImageRow = {
  id: string; folder_id: string | null; character_id?: string | null; storage_path: string; original_name: string;
  title: string | null; description: string | null; mime_type: string; bytes: number;
  sort_order: number; created_at: string; signedUrl?: string; tags?: string[];
};
type TagRow = { id: string; name: string };
type CharacterRow = { id: string; name: string; slug: string; description: string | null; cover_path: string | null; coverUrl?: string };

const BUCKET = "archiva-images";

export default function App() {
  const [session, setSession] = useState<any>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authMode, setAuthMode] = useState<"login" | "signup">("login");
  const [folders, setFolders] = useState<FolderRow[]>([]);
  const [images, setImages] = useState<ImageRow[]>([]);
  const [tags, setTags] = useState<TagRow[]>([]);
  const [characters, setCharacters] = useState<CharacterRow[]>([]);
  const [activeCharacter, setActiveCharacter] = useState<string | null>(null);
  const [characterDraft, setCharacterDraft] = useState("");
  const [characterDescriptionDraft, setCharacterDescriptionDraft] = useState("");
  const [editCharacter, setEditCharacter] = useState("");
  const [editFolder, setEditFolder] = useState("");
  const [activeFolder, setActiveFolder] = useState<string | null>(null);
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [view, setView] = useState<"grid" | "feed">("grid");
  const [selected, setSelected] = useState<ImageRow | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editDescription, setEditDescription] = useState("");
  const [editTags, setEditTags] = useState("");
  const [folderDraft, setFolderDraft] = useState("");
  const [editingFolder, setEditingFolder] = useState<string | null>(null);
  const [folderNameDraft, setFolderNameDraft] = useState("");
  const [newTag, setNewTag] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [mobileNav, setMobileNav] = useState(false);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => { if (session?.user?.id) void loadLibrary(); }, [session?.user?.id]);

  async function loadLibrary() {
    if (!supabase || !session?.user?.id) return;
    setBusy(true);
    const [f, i, t, relations, c] = await Promise.all([
      supabase.from("folders").select("id,name,description,parent_id,sort_order").order("sort_order").order("name"),
      supabase.from("images").select("*").order("created_at", { ascending: false }),
      supabase.from("tags").select("id,name").order("name"),
      supabase.from("image_tags").select("image_id,tag_id,tags(name)"),
      supabase.from("characters").select("id,name,slug,description,cover_path").order("sort_order").order("name")
    ]);
    if (f.error || i.error || t.error) setMessage(f.error?.message || i.error?.message || t.error?.message || "No se pudo cargar la biblioteca.");
    const relationMap = new Map<string, string[]>();
    for (const relation of (relations.data || []) as any[]) {
      const name = Array.isArray(relation.tags) ? relation.tags[0]?.name : relation.tags?.name;
      if (name) relationMap.set(relation.image_id, [...(relationMap.get(relation.image_id) || []), name]);
    }
    const rows = (i.data || []) as ImageRow[];
    const withUrls = await Promise.all(rows.map(async (row) => {
      const { data } = await supabase!.storage.from(BUCKET).createSignedUrl(row.storage_path, 3600);
      return { ...row, tags: relationMap.get(row.id) || [], signedUrl: data?.signedUrl };
    }));
    setFolders((f.data || []) as FolderRow[]);
    setImages(withUrls);
    setTags((t.data || []) as TagRow[]);
    const characterRows = (c.data || []) as CharacterRow[];
    const withCovers = await Promise.all(characterRows.map(async character => {
      if (!character.cover_path) return character;
      const { data } = await supabase!.storage.from(BUCKET).createSignedUrl(character.cover_path, 3600);
      return { ...character, coverUrl: data?.signedUrl };
    }));
    setCharacters(withCovers);
    setBusy(false);
  }

  async function authenticate(e: FormEvent) {
    e.preventDefault();
    if (!supabase) return;
    setBusy(true); setMessage("");
    const result = authMode === "login"
      ? await supabase.auth.signInWithPassword({ email, password })
      : await supabase.auth.signUp({ email, password });
    setMessage(result.error?.message || (authMode === "signup" ? "Cuenta creada. Si se solicita, confirmá tu correo." : ""));
    setBusy(false);
  }

  async function signOut() { await supabase?.auth.signOut(); setSession(null); }

  async function signInWithGoogle() {
    if (!supabase) return;
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: window.location.origin }
    });
    if (error) setMessage(error.message);
  }

  async function createFolder(e: FormEvent) {
    e.preventDefault();
    if (!supabase || !folderDraft.trim()) return;
    const { error } = await supabase.from("folders").insert({ name: folderDraft.trim(), user_id: session.user.id, sort_order: folders.length });
    if (error) setMessage(error.message); else { setFolderDraft(""); await loadLibrary(); }
  }

  async function renameFolder(id: string) {
    if (!supabase || !folderNameDraft.trim()) return;
    const { error } = await supabase.from("folders").update({ name: folderNameDraft.trim() }).eq("id", id);
    if (error) setMessage(error.message);
    setEditingFolder(null); await loadLibrary();
  }

  async function deleteFolder(id: string) {
    if (!supabase) return;
    const hasImages = images.some(x => x.folder_id === id);
    if (hasImages) { setMessage("Mové o eliminá las imágenes de esta carpeta antes de borrarla."); return; }
    const hasChildren = folders.some(x => x.parent_id === id);
    if (hasChildren) { setMessage("Primero eliminá o reorganizá las subcarpetas."); return; }
    const { error } = await supabase.from("folders").delete().eq("id", id);
    if (error) setMessage(error.message);
    if (activeFolder === id) setActiveFolder(null);
    await loadLibrary();
  }

  async function createCharacter(e: FormEvent) {
    e.preventDefault();
    if (!supabase || !characterDraft.trim()) return;
    const name = characterDraft.trim();
    const slug = name.normalize("NFD").replace(/[\\u0300-\\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    const { error } = await supabase.from("characters").insert({
      user_id: session.user.id, name, slug: slug || crypto.randomUUID(), description: characterDescriptionDraft.trim() || null,
      sort_order: characters.length
    });
    if (error) setMessage(error.message);
    setCharacterDraft(""); setCharacterDescriptionDraft("");
    await loadLibrary();
  }

  async function uploadCharacterCover(character: CharacterRow, file: File | null) {
    if (!supabase || !file) return;
    if (!file.type.startsWith("image/") || file.size > 50 * 1024 * 1024) {
      setMessage("La portada debe ser una imagen de hasta 50 MB."); return;
    }
    setBusy(true);
    const path = `${session.user.id}/covers/${character.id}-${crypto.randomUUID()}-${file.name.replace(/[^\\w.-]/g, "_")}`;
    const { error: uploadError } = await supabase.storage.from(BUCKET).upload(path, file, { contentType: file.type });
    if (uploadError) setMessage(uploadError.message);
    else {
      const { error } = await supabase.from("characters").update({ cover_path: path }).eq("id", character.id);
      if (error) { setMessage(error.message); await supabase.storage.from(BUCKET).remove([path]); }
      else if (character.cover_path) await supabase.storage.from(BUCKET).remove([character.cover_path]);
    }
    await loadLibrary(); setBusy(false);
  }

  async function deleteCharacter(character: CharacterRow) {
    if (!supabase) return;
    const { error } = await supabase.from("characters").delete().eq("id", character.id);
    if (error) setMessage(error.message);
    else {
      if (character.cover_path) await supabase.storage.from(BUCKET).remove([character.cover_path]);
      if (activeCharacter === character.id) setActiveCharacter(null);
    }
    await loadLibrary();
  }

  async function uploadFiles(filesList: FileList | null) {
    if (!supabase || !filesList?.length) return;
    setBusy(true); setMessage("");
    const allowed = ["image/jpeg","image/png","image/webp","image/gif","image/avif","image/heic"];
    for (const file of Array.from(filesList)) {
      if (!allowed.includes(file.type)) { setMessage(`Formato no admitido: ${file.name}`); continue; }
      if (file.size > 50 * 1024 * 1024) { setMessage(`${file.name} supera el límite de 50 MB.`); continue; }
      const path = `${session.user.id}/${crypto.randomUUID()}-${file.name.replace(/[^\w.-]/g, "_")}`;
      const upload = await supabase.storage.from(BUCKET).upload(path, file, { contentType: file.type, upsert: false });
      if (upload.error) { setMessage(upload.error.message); continue; }
      const insert = await supabase.from("images").insert({
        user_id: session.user.id, folder_id: activeFolder, storage_path: path,
        original_name: file.name, mime_type: file.type, bytes: file.size, sort_order: 0
      });
      if (insert.error) { await supabase.storage.from(BUCKET).remove([path]); setMessage(insert.error.message); }
    }
    await loadLibrary(); setBusy(false);
  }

  async function saveImage() {
    if (!supabase || !selected) return;
    setBusy(true);
    const { error } = await supabase.from("images").update({
      title: editTitle.trim() || null, description: editDescription.trim() || null,
      character_id: editCharacter || null, folder_id: editFolder || null
    }).eq("id", selected.id);
    if (error) setMessage(error.message);
    await syncImageTags(selected.id, editTags);
    await loadLibrary();
    setSelected(null); setBusy(false);
  }

  async function syncImageTags(imageId: string, raw: string) {
    if (!supabase) return;
    const names = [...new Set(raw.split(",").map(x => x.trim()).filter(Boolean))];
    const current = tags;
    const ids: string[] = [];
    for (const name of names) {
      let tag = current.find(t => t.name.toLowerCase() === name.toLowerCase());
      if (!tag) {
        const { data: created, error } = await supabase.from("tags").insert({ user_id: session.user.id, name }).select("id,name").single();
        if (error) {
          const { data: existing } = await supabase.from("tags").select("id,name").ilike("name", name).maybeSingle();
          if (!existing) { setMessage(error.message); continue; }
          tag = existing as TagRow;
        } else tag = created as TagRow;
      }
      ids.push(tag.id);
    }
    await supabase.from("image_tags").delete().eq("image_id", imageId);
    if (ids.length) await supabase.from("image_tags").insert(ids.map(tag_id => ({ user_id: session.user.id, image_id: imageId, tag_id })));
  }

  async function deleteImage(row: ImageRow) {
    if (!supabase) return;
    setBusy(true);
    const { error: storageError } = await supabase.storage.from(BUCKET).remove([row.storage_path]);
    if (storageError) setMessage(storageError.message);
    else {
      const { error } = await supabase.from("images").delete().eq("id", row.id);
      if (error) setMessage(error.message);
    }
    setSelected(null); await loadLibrary(); setBusy(false);
  }

  async function createTag(e: FormEvent) {
    e.preventDefault();
    if (!supabase || !newTag.trim()) return;
    const { error } = await supabase.from("tags").insert({ user_id: session.user.id, name: newTag.trim() });
    if (error) {
      const { data: existing } = await supabase.from("tags").select("id").ilike("name", newTag.trim()).maybeSingle();
      if (!existing) setMessage(error.message);
    }
    setNewTag(""); await loadLibrary();
  }

  const visibleImages = useMemo(() => images.filter(row => {
    const matchesFolder = !activeFolder || row.folder_id === activeFolder;
    const matchesCharacter = !activeCharacter || row.character_id === activeCharacter;
    const selectedTag = !activeTag || (row.tags || []).some(name => name === tags.find(t => t.id === activeTag)?.name);
    const matchesSearch = !query || `${row.title || ""} ${row.original_name} ${row.description || ""}`.toLowerCase().includes(query.toLowerCase());
    return matchesFolder && matchesCharacter && selectedTag && matchesSearch;
  }), [images, activeFolder, activeCharacter, activeTag, tags, query]);

  function openImage(row: ImageRow) {
    setSelected(row); setEditTitle(row.title || ""); setEditDescription(row.description || "");
    setEditTags((row.tags || []).join(", "));
    setEditCharacter(row.character_id || "");
    setEditFolder(row.folder_id || "");
  }

  if (!isSupabaseConfigured) return <main className="setup"><div className="brand-mark">A</div><p className="eyebrow">TU BIBLIOTECA VISUAL</p><h1>ARCHIVA</h1><p>El proyecto está preparado. Para conectar tu biblioteca, copiá la publishable key de Supabase en el archivo <code>.env</code>.</p><code>VITE_SUPABASE_PUBLISHABLE_KEY=...</code><small>La clave secreta de service role nunca debe colocarse en el navegador.</small></main>;

  if (!session) return <main className="auth-screen"><section className="auth-card"><div className="brand-mark">A</div><p className="eyebrow">TU ESPACIO, TU COLECCIÓN</p><h1>ARCHIVA</h1><p className="muted">Una biblioteca visual hecha a tu manera.</p><form onSubmit={authenticate}><label>Correo electrónico<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required /></label><label>Contraseña<input type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength={6} required /></label><button className="primary" disabled={busy}>{busy ? "Un momento…" : authMode === "login" ? "Iniciar sesión" : "Crear cuenta"}</button></form><div className="auth-divider"><span>o</span></div><button className="google-button" onClick={()=>void signInWithGoogle()}><span className="google-g">G</span> Continuar con Google</button><button className="text-button" onClick={()=>setAuthMode(authMode === "login" ? "signup" : "login")}>{authMode === "login" ? "¿Primera vez? Crear cuenta" : "Ya tengo una cuenta"}</button>{message && <p className="notice">{message}</p>}</section></main>;

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? "open" : ""}`}>
      <div className="brand"><div className="brand-mark small">A</div><span>ARCHIVA</span><button className="icon-button mobile-close" onClick={()=>setMobileNav(false)}><X size={18}/></button></div>
      <button className={`nav-item ${!activeFolder && !activeCharacter ? "active" : ""}`} onClick={()=>{setActiveFolder(null);setActiveCharacter(null);setMobileNav(false)}}><Archive size={18}/> Toda la biblioteca <span>{images.length}</span></button>
      <div className="side-heading"><span>CARPETAS</span><FolderPlus size={16}/></div>
      <form className="inline-create" onSubmit={createFolder}><input value={folderDraft} onChange={e=>setFolderDraft(e.target.value)} placeholder="Nueva carpeta…" aria-label="Nombre de carpeta"/><button aria-label="Crear carpeta"><Plus size={16}/></button></form>
      <div className="folder-list">{folders.map(folder=><div className={`folder-line ${activeFolder===folder.id?"selected":""}`} key={folder.id}>
        {editingFolder===folder.id ? <form className="rename-form" onSubmit={e=>{e.preventDefault();void renameFolder(folder.id)}}><input autoFocus value={folderNameDraft} onChange={e=>setFolderNameDraft(e.target.value)}/><button><Check size={14}/></button></form> : <><button className="folder-button" onClick={()=>{setActiveFolder(folder.id);setMobileNav(false)}}><Folder size={16}/><span>{folder.name}</span></button><div className="folder-actions"><button title="Renombrar" onClick={()=>{setEditingFolder(folder.id);setFolderNameDraft(folder.name)}}><Pencil size={13}/></button><button title="Eliminar" onClick={()=>void deleteFolder(folder.id)}><Trash2 size={13}/></button></div></>}
      </div>)}</div>
      <div className="side-heading tag-heading"><span>PERSONAJES</span><Sparkles size={15}/></div>
      <form className="character-create" onSubmit={createCharacter}>
        <input value={characterDraft} onChange={e=>setCharacterDraft(e.target.value)} placeholder="Nombre del personaje…" aria-label="Nombre del personaje"/>
        <input value={characterDescriptionDraft} onChange={e=>setCharacterDescriptionDraft(e.target.value)} placeholder="Descripción breve (opcional)" aria-label="Descripción del personaje"/>
        <button className="character-add"><Plus size={15}/> Crear ficha</button>
      </form>
      <div className="character-list">{characters.map(character=><div className={`character-line ${activeCharacter===character.id?"selected":""}`} key={character.id}>
        <button className="character-button" onClick={()=>{setActiveCharacter(activeCharacter===character.id?null:character.id);setActiveFolder(null);setMobileNav(false)}}>
          {character.coverUrl ? <img src={character.coverUrl} alt=""/> : <span className="character-avatar">{character.name.slice(0,1).toUpperCase()}</span>}
          <span>{character.name}</span>
        </button>
        <label className="cover-action" title="Cambiar portada"><Upload size={13}/><input type="file" accept="image/*" onChange={e=>void uploadCharacterCover(character,e.target.files?.[0] || null)}/></label>
        <button className="cover-action" title="Eliminar ficha" onClick={()=>void deleteCharacter(character)}><Trash2 size={13}/></button>
      </div>)}</div>
      <div className="side-heading tag-heading"><span>ETIQUETAS</span><Tag size={15}/></div>
      <form className="inline-create" onSubmit={createTag}><input value={newTag} onChange={e=>setNewTag(e.target.value)} placeholder="Nueva etiqueta…" aria-label="Nueva etiqueta"/><button aria-label="Crear etiqueta"><Plus size={16}/></button></form>
      <div className="tag-list">{tags.map(tag=><button key={tag.id} className={`tag-chip ${activeTag===tag.id?"chosen":""}`} onClick={()=>setActiveTag(activeTag===tag.id?null:tag.id)}>#{tag.name}</button>)}</div>
      <div className="sidebar-bottom"><div className="user-dot">{session.user.email?.[0]?.toUpperCase() || "U"}</div><span>{session.user.email}</span><button className="icon-button" onClick={signOut} title="Cerrar sesión"><LogOut size={17}/></button></div>
    </aside>
    {mobileNav && <button className="scrim" onClick={()=>setMobileNav(false)} aria-label="Cerrar menú"/>}
    <main className="main-content">
      <header className="topbar"><button className="icon-button menu-button" onClick={()=>setMobileNav(true)}><Menu/></button><div className="crumb"><span>Biblioteca</span>{activeFolder && <><ChevronRight size={14}/><strong>{folders.find(f=>f.id===activeFolder)?.name}</strong></>}</div><div className="top-actions"><div className="search-box"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Buscar en ARCHIVA…"/></div><label className="upload-button"><Upload size={17}/><span>Subir imágenes</span><input type="file" accept="image/jpeg,image/png,image/webp,image/gif,image/avif,image/heic" multiple onChange={e=>void uploadFiles(e.target.files)}/></label></div></header>
      <section className="page-heading"><div><p className="eyebrow">COLECCIÓN PERSONAL</p><h2>{activeFolder ? folders.find(f=>f.id===activeFolder)?.name : activeCharacter ? characters.find(c=>c.id===activeCharacter)?.name : "Tu biblioteca"}</h2><p className="muted">{visibleImages.length} {visibleImages.length===1?"imagen":"imágenes"} en esta colección</p></div><div className="view-switch"><button className={view==="grid"?"selected":""} onClick={()=>setView("grid")} title="Cuadrícula"><LayoutGrid size={18}/></button><button className={view==="feed"?"selected":""} onClick={()=>setView("feed")} title="Recorrido vertical"><Rows3 size={18}/></button></div></section>
      {message && <div className="notice-bar">{message}<button onClick={()=>setMessage("")}><X size={15}/></button></div>}
      {busy && <div className="loading-line"/>}
      {visibleImages.length===0 ? <div className="empty-state"><div className="empty-icon"><ImageIcon size={28}/></div><h3>Tu espacio está listo</h3><p>Subí tus primeras imágenes o creá carpetas para empezar a organizar tu colección.</p><label className="primary upload-empty"> <Upload size={16}/> Elegir imágenes<input type="file" accept="image/*" multiple onChange={e=>void uploadFiles(e.target.files)}/></label></div> :
        view==="grid" ? <div className="image-grid">{visibleImages.map(row=><button className="image-card" key={row.id} onClick={()=>openImage(row)}><img src={row.signedUrl} alt={row.title || row.original_name} loading="lazy"/><span className="image-caption"><strong>{row.title || row.original_name}</strong><small>{row.description || "Sin descripción"}</small></span></button>)}</div> :
        <div className="vertical-feed">{visibleImages.map(row=><article className="feed-card" key={row.id}><button className="feed-image" onClick={()=>openImage(row)}><img src={row.signedUrl} alt={row.title || row.original_name}/></button><div className="feed-caption"><div><strong>{row.title || row.original_name}</strong><p>{row.description || " "}</p></div><button className="secondary" onClick={()=>openImage(row)}>Editar</button></div></article>)}</div>
      }
      <footer className="footer-note"><Sparkles size={14}/> ARCHIVA · tu colección, en orden.</footer>
    </main>
    {selected && <div className="modal-backdrop" onClick={()=>setSelected(null)}><section className="image-modal" onClick={e=>e.stopPropagation()}><button className="modal-close icon-button" onClick={()=>setSelected(null)}><X/></button><div className="modal-preview"><img src={selected.signedUrl} alt={selected.original_name}/></div><div className="modal-editor"><p className="eyebrow">DETALLES DE LA IMAGEN</p><h3>Editar imagen</h3><label>Título<input value={editTitle} onChange={e=>setEditTitle(e.target.value)} placeholder="Un título para esta imagen"/></label><label>Descripción<textarea value={editDescription} onChange={e=>setEditDescription(e.target.value)} rows={3} placeholder="Agregá algún detalle…"/></label><label>Etiquetas <small>Separadas por comas</small><input value={editTags} onChange={e=>setEditTags(e.target.value)} placeholder="retrato, referencia, favorita"/></label><label>Personaje<select value={editCharacter} onChange={e=>setEditCharacter(e.target.value)}><option value="">Sin personaje</option>{characters.map(character=><option key={character.id} value={character.id}>{character.name}</option>)}</select></label><label>Carpeta<select value={editFolder} onChange={e=>setEditFolder(e.target.value)}><option value="">Sin carpeta</option>{folders.map(folder=><option key={folder.id} value={folder.id}>{folder.name}</option>)}</select></label><div className="modal-buttons"><button className="danger" onClick={()=>void deleteImage(selected)}><Trash2 size={16}/> Eliminar</button><button className="primary" onClick={()=>void saveImage()} disabled={busy}><Check size={16}/> Guardar cambios</button></div></div></section></div>}
  </div>;
}
