import { createClient } from "@supabase/supabase-js";

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined;

export const isSupabaseConfigured = Boolean(url && key && !key.includes("PEGAR_AQUI"));
export const supabase = isSupabaseConfigured ? createClient(url!, key!) : null;
